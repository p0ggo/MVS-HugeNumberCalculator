var searchData=
[
  ['next_58',['next',['../struct_node.html#af67b110ca1a258b793bf69d306929b22',1,'Node']]],
  ['node_59',['Node',['../struct_node.html',1,'Node'],['../_doubly_linked_list_8h.html#a9cf2efdb4ec5c59749c71c81ce1cf726',1,'Node():&#160;DoublyLinkedList.h']]]
];
