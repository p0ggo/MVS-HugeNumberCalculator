var searchData=
[
  ['next_139',['next',['../struct_node.html#af67b110ca1a258b793bf69d306929b22',1,'Node']]]
];
