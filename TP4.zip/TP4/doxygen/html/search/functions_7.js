var searchData=
[
  ['simplifyhugefloat_130',['simplifyHugeFloat',['../_huge_float_operator_8h.html#a718ef0c064b8fb6a04e223413bf8b441',1,'HugeFloatOperator.c']]],
  ['simplifyhugeint_131',['simplifyHugeInt',['../_huge_int_8h.html#af95097c0bbde218d8b8d743eec89001e',1,'HugeInt.c']]],
  ['simplifyhugeunsignedint_132',['simplifyHugeUnsignedInt',['../_huge_unsigned_int_8h.html#abef7b623f54d5ef57e36eccd305fde5e',1,'HugeUnsignedInt.c']]],
  ['substracthugefloat_133',['substractHugeFloat',['../_huge_float_operator_8h.html#ae8ad2e2d5fc7489cafc5c72a2144f99c',1,'HugeFloatOperator.c']]],
  ['substracthugeint_134',['substractHugeInt',['../_huge_int_operator_8h.html#aaef19adb5278a6a10f6bc0693b4b80e9',1,'HugeIntOperator.c']]],
  ['substracthugeunsignedint_135',['substractHugeUnsignedInt',['../_huge_unsigned_int_operator_8h.html#aaf0ea1f2df37fcceb0205e072693fd4b',1,'HugeUnsignedIntOperator.c']]]
];
