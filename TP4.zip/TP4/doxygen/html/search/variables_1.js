var searchData=
[
  ['digit_137',['digit',['../struct_node.html#a78a2971a1056156209f2dad0e50d779d',1,'Node']]]
];
