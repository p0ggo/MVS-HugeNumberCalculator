var searchData=
[
  ['removeendfromdoublylinkedlist_62',['removeEndFromDoublyLinkedList',['../_doubly_linked_list_8h.html#afee2bb4698ee9a8cfc1eb786fe1a5ad5',1,'DoublyLinkedList.c']]],
  ['removestartfromdoublylinkedlist_63',['removeStartFromDoublyLinkedList',['../_doubly_linked_list_8h.html#a888f58d614d7dd872d15e19515ed82ef',1,'DoublyLinkedList.c']]]
];
