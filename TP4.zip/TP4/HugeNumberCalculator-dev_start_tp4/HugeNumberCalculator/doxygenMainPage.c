/**
 * \mainpage HugeNumberCalculator
 * # A calculator for handling huge numbers.
 * ##  A sample project in C language to learn how to use :
 *   - Git
 *   - GitHub
 *   - Doxygen
 *   - Microsoft Visual Community
 */
