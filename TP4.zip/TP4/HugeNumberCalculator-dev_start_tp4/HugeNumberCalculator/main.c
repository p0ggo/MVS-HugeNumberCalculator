#include <stdlib.h>
#include <stdio.h>
#include "UseHugeNumber/Type/HugeFloat.h"
#include "UseHugeNumber/Type/HugeInt.h"
#include "UseHugeNumber/Type/HugeUnsignedInt.h"
#include "UseHugeNumber/Operator/HugeFloatOperator.h"
#include "UseHugeNumber/Operator/HugeIntOperator.h"
#include "UseHugeNumber/Operator/HugeUnsignedIntOperator.h"
#include "IHMHugeNumber/ScanHugeNumber.h"
#include "IHMHugeNumber/ShowHugeNumber.h"
int main(void) {
	HugeInt* op1 = createHugeIntFromString("+1");
	HugeInt* op2 = createHugeIntFromString("+2");
	HugeInt* result = divideHugeInt(op1, op2);
	deleteHugeInt(op1);
	deleteHugeInt(op2);
	deleteHugeInt(result);
	return EXIT_SUCCESS;
}