/*****************************************************************//**
 * \file   ScanHugeNumber.h
 * \brief  
 *		\n Example :
*		 \code{.c}
 *		HugeInt* hugeInt = scanHugeInt();
 *		 \endcode
 * 
 * \author Alexandre
 * \date   November 2020
 *********************************************************************/
#ifndef SCAN_HUGE_NUMBER
#define SCAN_HUGE_NUMBER

#include "../UseHugeNumber/Type/HugeInt.h"

extern HugeInt* scanHugeInt (void);
extern HugeUnsignedInt* scanHugeUnsignedInt (void);

#endif // !SCAN_HUGE_NUMBER
