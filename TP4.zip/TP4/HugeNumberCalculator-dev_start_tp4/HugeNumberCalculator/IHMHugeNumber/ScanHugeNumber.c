#include <stdio.h>
#include "ScanHugeNumber.h"

#define MAX_SCANF_S_SIZE 1000

HugeInt* scanHugeInt (void) {
    char hugeIntInString[1000];
    if (scanf_s ("%s", hugeIntInString, MAX_SCANF_S_SIZE) == EOF)
        return NULL;
    return createHugeIntFromString (hugeIntInString);
}

HugeUnsignedInt* scanHugeUnsignedInt (void) {
    char hugeUnsignedIntInString[1000];
    if (scanf_s ("%s", hugeUnsignedIntInString, MAX_SCANF_S_SIZE) == EOF)
        return NULL;
    return createHugeUnsignedIntFromString (hugeUnsignedIntInString);
}